# package/governed Scan

Root: `/home/developer/projects/FS-Skia-UI/artifacts/template-check/034-asteroids-feedback-skills/package-governed`
Files scanned: 117
Placeholder scan: PASS
Excluded-history scan: PASS
V3 framework-source exclusion scan: PASS
V3 selected package reference scan: PASS
Spec Kit install scan: PASS
Generated AGENTS scan: PASS
Executable script scan: PASS
Generated Dev elapsed: 1.9 seconds
Visual support: non-visual V3 validation only; full visual evidence is deferred.
