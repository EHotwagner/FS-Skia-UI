# Bootstrap Runner Evidence

- target: `Verify`
- timestamp-utc: `2026-05-17T17:48:32.9024722+00:00`
- dotnet-sdk-status: `pass`
- fake-tool-restore-status: `pass`
- package-cache-status: `pass`
- wrapper-status: `pass`
- warning-classification: runner-warning-classification: repeated netstandard script-load warning is warning-noise unless target exits nonzero; CoreCLR/VSTest/socket/thread startup failures are environment-failure evidence
- passed: `True`
- remediation-command: (none)
