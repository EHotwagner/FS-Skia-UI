# package/governed Scan

Root: `/home/developer/projects/FS-Skia-UI/artifacts/template-check/016-persistent-viewer-contract/package-governed`
Files scanned: 84
Placeholder scan: PASS
Excluded-history scan: PASS
V3 framework-source exclusion scan: PASS
V3 selected package reference scan: PASS
Spec Kit install scan: PASS
Generated AGENTS scan: PASS
Executable script scan: PASS
Generated Dev elapsed: 2.1 seconds
Visual support: non-visual V3 validation only; full visual evidence is deferred.
