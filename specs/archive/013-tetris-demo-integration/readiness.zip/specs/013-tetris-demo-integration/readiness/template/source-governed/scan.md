# source/governed Scan

Root: `/home/developer/projects/FS-Skia-UI/artifacts/template-check/013-tetris-demo-integration/source-governed`
Files scanned: 84
Placeholder scan: PASS
Excluded-history scan: PASS
V3 framework-source exclusion scan: PASS
V3 selected package reference scan: PASS
Spec Kit install scan: PASS
Generated AGENTS scan: PASS
Executable script scan: PASS
Generated Dev elapsed: 1.3 seconds
Visual support: non-visual V3 validation only; full visual evidence is deferred.
